def fib():
	print(
