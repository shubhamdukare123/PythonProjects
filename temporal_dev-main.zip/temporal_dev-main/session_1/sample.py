print("hh")
