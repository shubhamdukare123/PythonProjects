x = print("H")
print(x)
